export interface Product {

    p_id : number,

   product_name : string,

   product_weight : string,

   product_price : number,

   product_image :string

}